<?php getHead(); ?>

   

<div class="content-wrapper">

    <!-- Content Header (Page header) -->

<section class="content-header">

      <h1>

      Translation Managment

        

      </h1>

    

    </section>

    <!-- Main content -->

    <section class="content">

      <div class="row">

        <div class="col-xs-12">

          <div class="box">

            <div class="box-header">

              

            </div>

            <!-- /.box-header -->

             <div class="box-body">

                <table id="post_table" class="table table-striped table-bordered   responsive">

    <thead>
   

    <tr>

        <th>Name</th>

        <th>Email</th>

        <th>Previous User Type</th>

        <th>Want User Type</th>

        <th>Options</th>

    </tr>

    </thead>

    <tbody>

    <?php

	if(!empty($data)){

	foreach ($data as $d){

		
// pre($id);
		?>

		<tr id="row_<?php echo$row->id;?>">

		<td><?php echo $d['name'];?></td>    

                <td><?php echo $d['email'];?></td>
                        <?php  if($d['previous_usertype']==3){
                                $p_utype='Desinsectiseur';
                        }elseif($d['previous_usertype']==4){
                                $p_utype='Particulier';
                        } elseif($d['previous_usertype']==5){
                                $p_utype='Collectivités';
                        }  ?>
                <td><?php echo $p_utype;?></td>
                                <?php  if($d['want_usertype']==3){
                                $w_utype='Desinsectiseur';
                        }elseif($d['want_usertype']==4){
                                $w_utype='Particulier';
                        } elseif($d['want_usertype']==5){
                                $w_utype='Collectivités';
                        }  ?>

                <td><?php echo $w_utype;?></td>
             <td class="center">

            <a data-toggle="tooltip" title=" <?php echo ucwords(this_lang('Edit'));?>" class="btn btn-xs btn-danger" href="user_type_change/operation_user_type/cancel/<?php echo $d['id'];?>">

               cancel

                

            </a>
             <a data-toggle="tooltip" title=" <?php echo ucwords(this_lang('Edit'));?>" class="btn btn-xs btn-success" href="user_type_change/operation_user_type/accept/<?php echo $d['id'].'/'.$d['userid'].'/'.$d['want_usertype'];?>">

               accept

                

            </a>

           

        </td>

    </tr>

    

		<?php }

	}

		

	?>

    

    </tbody>

    </table>

                  </div>  

                    

                

                

          

          </div>

          

          <!-- /.box -->

        </div>

        <!-- /.col -->

      </div>

      <!-- /.row -->

    </section>

    <!-- /.content -->

  </div>

   



  <?php  getFooter(); ?>

<script>

$('#post_table').dataTable( {

  "ordering": false

} );

</script>

  

  

  

  