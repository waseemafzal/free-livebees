<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Allnests extends MX_Controller {

	public function __construct(){
		parent::__construct();
		if(!$this->session->userdata('login')==true){
			redirect('auth/login', 'refresh');
		}
		$this->load->library("pagination");
	}
	
	public $tbl = 'tbl_loc';
	public $tbl_invites = 'invites';
	
	public function index()
	{  
	
	$config = array();
        $config["base_url"] = base_url() . "allnests/index";
        $config["total_rows"] = getcount($this->tbl);
        $config["per_page"] = 20;
        $config["uri_segment"] = 3;
		$this->pagination->initialize($config);

        $page = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;
		$data = $this->fetch_feed($config["per_page"], $page);
        $aData['links'] = $this->pagination->create_links();
		 $aData['data'] =$data;
		$this->load->view('index',$aData);
		//$this->load->view('index');
	}
	
	function importcsv(){
		
		$count=0;
		$response=array();
        $fp = fopen($_FILES['file']['tmp_name'],'r') or die("can't open file");
        while($csv_line = fgetcsv($fp,1024))
        {
            $count++;
            if($count == 1)
            {
                continue;
            }//keep this if condition if you want to remove the first row
            for($i = 0, $j = count($csv_line); $i < $j; $i++)
            {
                $insert_csv = array();
                $insert_csv['status'] = $csv_line[0];
                $insert_csv['address'] = $csv_line[1];
                $insert_csv['added_date'] = $csv_line[2];
                $insert_csv['hight_in_meters'] = $csv_line[3];
                 $insert_csv['description'] = $csv_line[6];
                $insert_csv['lat'] = $csv_line[7];
                $insert_csv['lon'] = $csv_line[8];
                $insert_csv['diameter'] = $csv_line[10];
                $insert_csv['support'] = $csv_line[11];
                $insert_csv['nest_type'] = $csv_line[12];
                $insert_csv['name'] = $csv_line[13];

            }
            $i++;
            $data = array(
                'status' => $insert_csv['status'],
                'address' => $insert_csv['address'],
                'added_date' => $insert_csv['added_date'],
                'hight_in_meters' => $insert_csv['hight_in_meters'],
                'description' => $insert_csv['description'],
                'lat' => $insert_csv['lat'],
                'lon' => $insert_csv['lon'],
                'diameter' => $insert_csv['diameter'],
                'support' => $insert_csv['support'],
                'nest_type' => $insert_csv['nest_type'],
                'name' => $insert_csv['name']
				);
           $this->db->insert('tbl_loc', $data);
		   $this->db->insert('tbl_map_images', array('map_id'=>$this->db->insert_id(),'file'=>$csv_line[5],'type'=>2));
        }
        fclose($fp) or die("can't close file");
        $response['status']=1;
        $response['message']='Imported successfully';
       echo json_encode($response);
		}
	
	public function fetch_feed($limit, $start) {
        $this->db->limit($limit, $start);
		/*if(isset($_GET['activity_type']) and !empty($_GET['activity_type'])){
			$whereArray['activity_type_id']= $_GET['activity_type'];
			}
		*/
         $this->db->select("f.*")
		/*->join('activity_types as type','type.id=f.activity_type_id')
		->join('activity_feed_images as i','i.feed_id=f.id')
		->join('users as u','u.id=f.user_id')
		*//*->where($whereArray)*/
		->order_by('f.id','DESC');
		/*if(isset($_GET['posted_date']) and !empty($_GET['posted_date'])){
			$this->db->like('posted_date', $_GET['posted_date']);
			}*/
		
		
	$query =$this->db->get($this->tbl.' as f');
	
//lq();
        if ($query->num_rows() > 0) {
            
            return $query;
        }
        return false;
   }

}
